import React, { useState } from 'react';
import Grid from './components/grid';
import GridCard from './components/gridCards';
import Widgets, { WIDGETS } from './components/widgets';

interface Demo2Props {}

const Demo2 = (props: Demo2Props) => {
  const [widgets, setWidgets] = useState([]);

  return (
    <div className="relative flex flex-col">
      <div className="flex flex-row justify-start items-">
        <div className="w-1/4 border rounded flex flex-col justify-start items-center">
          <Widgets />
        </div>
        <div className="w-3/4 border rounded overflow-y-auto">
          <Grid setWidgets={setWidgets}>
            {(actions: any) =>
              widgets.map((widget: any) => {
                const { component: Widget, label } =
                  widget.type === 'barchart'
                    ? WIDGETS.barchart
                    : widget.type === 'grid'
                    ? WIDGETS.grid
                    : widget.type === 'map'
                    ? WIDGETS.map
                    : WIDGETS.chartCard;

                return (
                  Widget && (
                    <GridCard
                      key={widget.id}
                      actions={actions}
                      title={label}
                      {...widget}
                    >
                      <Widget />
                    </GridCard>
                  )
                );
              })
            }
          </Grid>
        </div>
      </div>
    </div>
  );
};

export default Demo2;
