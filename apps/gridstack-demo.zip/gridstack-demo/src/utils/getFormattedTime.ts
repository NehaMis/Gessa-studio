import moment from 'moment';
import 'moment-timezone';

export const getFormattedTime = (startTime: string, endTime: string) => {
  const monthAndDay = moment(startTime).format('MMM D, ddd');
  const start = moment(startTime).format('h:mm A');
  const end = moment(endTime).format('h:mmA');
  const timezone = moment.tz(moment.tz.guess()).zoneAbbr();

  return (
    monthAndDay +
    ' ' +
    start +
    ' - ' +
    end +
    ' ' +
    timezone
  ).toUpperCase();
};
