module.exports = {
  plugins: {
    tailwindcss: { config: './apps/test-app/tailwind.config.js' },
    autoprefixer: {},
  },
};
