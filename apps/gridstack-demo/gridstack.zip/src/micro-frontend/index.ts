export { default as getMicrofrontend } from './getMicrofrontend';
export { default as Microfrontend } from './getMicrofrontendComponent';

export default {};
