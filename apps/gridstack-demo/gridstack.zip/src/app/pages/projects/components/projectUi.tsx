import React from 'react';

interface Props {}

const projectUi = (props: Props) => {
  return <div>Projectui rendered</div>;
};

export default projectUi;
