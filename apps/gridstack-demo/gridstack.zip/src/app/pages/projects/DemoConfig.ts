import { lazy } from 'react';
import { IPageConfig } from '../../../types/pageConfig';

const ProjectConfig: IPageConfig = {
  settings: {
    showHeader: true,
  },
  routes: [
    {
      path: ['/demo'],
      component: lazy(() => import('./Demo2')),
      showInNavbar: true,
      name: 'Grid Demo',
      exact: true,
    },
  ],
};

export default ProjectConfig;
