import { IThemeColor } from '.';

const white: IThemeColor = {
  50: '#ffffff',
  100: '#ffffff',
  200: '#ffffff',
  300: '#ffffff',
  400: '#ffffff',
  500: '#ffffff',
  600: '#ffffff',
  700: '#ffffff',
  800: '#ffffff',
  900: '#ffffff',
  A100: '#fafafa',
  A200: '#e9e9e9',
  A400: '#e0e0e0',
  A700: '#d9d9d9',
  contrastDefaultColor: 'light',
};

export default white;
