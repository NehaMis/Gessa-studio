export const environment = {
  production: true,
  map_api_key: 'AIzaSyCjcBkWQ3IUwkMkzSnClkCR1iHIh-MlETk',
};
