export interface IPageConfig {
  settings?: ISettings;
  routes: IRoute[];
}
